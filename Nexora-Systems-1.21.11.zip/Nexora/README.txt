Nexora Systems 0.4.0 - Minecraft 1.21.11, Fabric, Yarn, Java 21

Open the menu:  Right Shift   or the chat command  /nexora   (phones: see below)
Settings persist in config/nexora.properties.

Build without installing anything: push this folder to a GitHub repo; the workflow
in .github/workflows/build.yml uploads the jar as an Actions artifact.
Build locally (Gradle 9.2.1 + JDK 21):  gradle wrapper --gradle-version 9.2.1 && ./gradlew build
Jar: build/libs/nexora-systems-0.4.0.jar  (not the -sources jar)

Phone (PojavLauncher / similar): install Fabric Loader + Fabric API for 1.21.11, put the jar in mods/.
In the launcher's control editor add a button mapped to Right Shift, or just type /nexora in chat.
The menu is tap/drag friendly: tap a row to toggle, drag sliders, drag empty space to scroll.

If compile fails, version-fragile calls are mostly in dev/nexora/client/Compat.java.
