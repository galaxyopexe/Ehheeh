package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;

/** Selects the best hotbar sword when the crosshair is on a player. Leaves a held mace alone. */
public final class AutoSword extends Module {
    private static final Item[] ORDER = {
        Items.NETHERITE_SWORD, Items.DIAMOND_SWORD, Items.IRON_SWORD,
        Items.STONE_SWORD, Items.GOLDEN_SWORD, Items.WOODEN_SWORD };

    @Override public String name() { return "AutoSword"; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || p.isUsingItem()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult h)
            || !(h.getEntity() instanceof PlayerEntity t) || t == p || !t.isAlive()) return;
        if (p.getMainHandStack().isOf(Items.MACE)) return;

        var inv = p.getInventory();
        int cur = rank(p.getMainHandStack().getItem());
        for (int r = 0; r < ORDER.length; r++) {
            if (cur >= 0 && cur <= r) return; // already holding this tier or better
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(ORDER[r])) {
                    if (Compat.selectedSlot(inv) != i) Compat.selectSlot(inv, i);
                    return;
                }
            }
        }
    }

    private static int rank(Item item) {
        for (int i = 0; i < ORDER.length; i++) if (ORDER[i] == item) return i;
        return -1;
    }
}
