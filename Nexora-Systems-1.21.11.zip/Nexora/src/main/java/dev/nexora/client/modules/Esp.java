package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.Draw;
import dev.nexora.client.Module;
import dev.nexora.client.Palette;
import dev.nexora.client.Projection;
import dev.nexora.client.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import java.util.Locale;

/** Player boxes with names and health, drawn from the same projection as the hitbox outline. */
public final class Esp extends Module {
    private final Setting range = add(new Setting("Range", 64, 16, 128, 8));
    private final Setting names = add(Setting.toggle("Names", true));

    @Override public String name() { return "ESP"; }
    @Override public Category category() { return Category.VISUAL; }

    @Override
    protected void onRender(DrawContext ctx, float pt) {
        if (!Compat.firstPerson(mc)) return;
        Projection pr = Compat.projection(mc, pt);
        int drawn = 0;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || !o.isAlive() || o.isSpectator() || drawn >= 16) continue;
            if (mc.player.distanceTo(o) > range.get()) continue;
            Box b = o.getBoundingBox();
            double[] off = Compat.renderOffset(o, pt);
            Draw.box(ctx, pr, b.minX + off[0], b.minY + off[1], b.minZ + off[2],
                     b.maxX + off[0], b.maxY + off[1], b.maxZ + off[2], Palette.VIOLET, 1);
            if (names.on()) {
                float[] top = pr.point((b.minX + b.maxX) / 2 + off[0], b.maxY + off[1] + 0.25, (b.minZ + b.maxZ) / 2 + off[2]);
                if (top != null) {
                    String s = o.getName().getString() + String.format(Locale.ROOT, "  %.0f", o.getHealth());
                    ctx.drawText(mc.textRenderer, s, Math.round(top[0]) - mc.textRenderer.getWidth(s) / 2,
                                 Math.round(top[1]) - 10, Palette.ICE, true);
                }
            }
            drawn++;
        }
    }
}
