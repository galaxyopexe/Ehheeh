package dev.nexora.client.modules;

import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/** After you land a click on a player, drops sprint for a few ticks so the next hit gets sprint knockback again. */
public final class WTap extends Module {
    private static volatile int block;
    private final Setting ticks = add(new Setting("Release ticks", 2, 1, 5, 1));
    private boolean attackWasDown;

    @Override public String name() { return "WTap"; }

    /** True while sprint should stay released (the Sprint module yields to it). */
    public static boolean blocking() { return block > 0; }

    @Override
    protected void onTick() {
        var p = mc.player;
        boolean down = mc.options.attackKey.isPressed();
        boolean rising = down && !attackWasDown;
        attackWasDown = down;

        if (rising && p.isSprinting() && mc.crosshairTarget instanceof EntityHitResult h
            && h.getEntity() instanceof PlayerEntity t && t != p) {
            block = (int) ticks.get();
        }
        if (block > 0) { p.setSprinting(false); block--; }
    }

    @Override protected void onDisable() { block = 0; }
}
