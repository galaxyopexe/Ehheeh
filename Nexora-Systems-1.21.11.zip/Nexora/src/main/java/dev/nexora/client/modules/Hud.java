package dev.nexora.client.modules;

import dev.nexora.client.Module;
import dev.nexora.client.NexoraClient;
import dev.nexora.client.Palette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Watermark (top left) and active-module list with live readouts such as Hitbox +0.30 (top right). */
public final class Hud extends Module {
    @Override public String name() { return "HUD"; }
    @Override public Category category() { return Category.VISUAL; }

    @Override
    protected void onRender(DrawContext ctx, float pt) {
        var tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();

        MutableText mark = Text.literal("NEX").formatted(Formatting.BOLD)
            .append(Text.literal("O").setStyle(Style.EMPTY.withBold(true).withColor(0x8B5CF6)))
            .append(Text.literal("RA").formatted(Formatting.BOLD))
            .append(Text.literal(" SYSTEMS").setStyle(Style.EMPTY.withColor(0xA78BFA)))
            .append(Text.literal("  " + mc.getCurrentFps() + " fps").setStyle(Style.EMPTY.withColor(Palette.MUTED & 0xFFFFFF)));
        int mw = tr.getWidth(mark);
        ctx.fill(4, 4, 4 + mw + 12, 20, Palette.PANEL);
        ctx.fill(4, 4, 6, 20, Palette.VIOLET);
        ctx.drawText(tr, mark, 10, 8, Palette.ICE, false);

        List<Module> on = new ArrayList<>();
        for (Module m : NexoraClient.MODULES.all()) if (m.enabled() && m != this) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> -tr.getWidth(label(m))));
        int y = 4;
        for (Module m : on) {
            String name = m.name(), info = m.info();
            int w = tr.getWidth(label(m));
            int x = sw - 4 - w - 10;
            ctx.fill(x, y, sw - 4, y + 13, Palette.PANEL);
            ctx.fill(sw - 6, y, sw - 4, y + 13, Palette.VIOLET);
            ctx.drawText(tr, name, x + 4, y + 3, Palette.ICE, false);
            if (!info.isEmpty()) ctx.drawText(tr, info, x + 4 + tr.getWidth(name) + 4, y + 3, Palette.PURPLE, false);
            y += 14;
        }
    }

    private static String label(Module m) { return m.info().isEmpty() ? m.name() : m.name() + " " + m.info(); }
}
