package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Wind-charge launch for a mace smash: on the ground near a target, throws a wind charge straight down, then returns to the mace. */
public final class WindBurst extends Module {
    private final Setting targetRange = add(new Setting("Target range", 8, 3, 16, 1));
    private final Setting cooldown    = add(new Setting("Cooldown ticks", 30, 10, 100, 5));
    private int cd, restoreSlot = -1;

    @Override public String name() { return "WindBurst"; }
    @Override public Category category() { return Category.MACE; }

    @Override
    protected void onTick() {
        var p = mc.player;
        var inv = p.getInventory();
        if (restoreSlot >= 0) { Compat.selectSlot(inv, restoreSlot); restoreSlot = -1; return; }
        if (cd > 0) { cd--; return; }
        if (!p.isOnGround() || mc.currentScreen != null || !mc.isWindowFocused()) return;

        int mace = slotOf(Items.MACE), wind = slotOf(Items.WIND_CHARGE);
        if (mace < 0 || wind < 0 || !hasTarget()) return;

        Compat.selectSlot(inv, wind);
        p.setPitch(90f);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        restoreSlot = mace;
        cd = (int) cooldown.get();
    }

    private int slotOf(Item item) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) if (inv.getStack(i).isOf(item)) return i;
        return -1;
    }

    private boolean hasTarget() {
        var p = mc.player;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            if (p.distanceTo(o) <= targetRange.get()) return true;
        }
        return false;
    }

    @Override protected void onDisable() { restoreSlot = -1; cd = 0; }
}
