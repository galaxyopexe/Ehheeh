package dev.nexora.client.modules;

import dev.nexora.client.Module;

public final class Sprint extends Module {
    @Override public String name() { return "Sprint"; }
    @Override public Category category() { return Category.MISC; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (!WTap.blocking() && mc.options.forwardKey.isPressed() && !p.horizontalCollision && !p.isSneaking()
            && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
