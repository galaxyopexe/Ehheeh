package dev.nexora.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Module {
    public enum Category { COMBAT("Combat"), MACE("Mace"), VISUAL("Visual"), MISC("Misc");
        public final String label; Category(String l) { label = l; } }

    private boolean enabled;
    private final List<Setting> settings = new ArrayList<>();
    protected final MinecraftClient mc = MinecraftClient.getInstance();

    public abstract String name();
    public Category category() { return Category.COMBAT; }
    /** Short live readout shown next to the name in the HUD list, e.g. "+0.30". */
    public String info() { return ""; }

    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick() {}
    protected void onRender(DrawContext ctx, float partialTick) {}

    protected final Setting add(Setting s) { settings.add(s); return s; }
    public final List<Setting> settings() { return Collections.unmodifiableList(settings); }
    public final boolean enabled() { return enabled; }

    public final void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    final void tick() { if (enabled && mc.player != null && mc.world != null) onTick(); }
    final void renderTick(DrawContext ctx, float pt) { if (enabled && mc.player != null && mc.world != null) onRender(ctx, pt); }
}
