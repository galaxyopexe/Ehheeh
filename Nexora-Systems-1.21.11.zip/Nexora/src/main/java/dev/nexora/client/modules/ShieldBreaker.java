package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/** When the crosshair player is blocking with a shield, swaps to an axe, hits once, and swaps back. */
public final class ShieldBreaker extends Module {
    private final Setting delay = add(new Setting("Swap delay ticks", 1, 0, 5, 1));
    private int stage, timer, restoreSlot = -1;

    @Override public String name() { return "ShieldBreaker"; }

    @Override
    protected void onTick() {
        var p = mc.player;
        var inv = p.getInventory();

        if (stage == 1) {
            if (timer > 0) { timer--; return; }
            PlayerEntity t = target();
            if (t != null && t.isBlocking()) { mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND); }
            stage = 2;
            return;
        }
        if (stage == 2) {
            if (restoreSlot >= 0) Compat.selectSlot(inv, restoreSlot);
            restoreSlot = -1; stage = 0;
            return;
        }

        if (mc.currentScreen != null) return;
        PlayerEntity t = target();
        if (t == null || !t.isBlocking()) return;

        if (p.getMainHandStack().isIn(ItemTags.AXES)) {
            if (p.getAttackCooldownProgress(0.5f) >= 0.95f) { mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND); }
            return;
        }
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isIn(ItemTags.AXES)) {
                restoreSlot = Compat.selectedSlot(inv);
                Compat.selectSlot(inv, i);
                stage = 1; timer = (int) delay.get();
                return;
            }
        }
    }

    private PlayerEntity target() {
        if (!(mc.crosshairTarget instanceof EntityHitResult h)) return null;
        return h.getEntity() instanceof PlayerEntity t && t != mc.player && t.isAlive() ? t : null;
    }

    @Override protected void onDisable() { stage = 0; restoreSlot = -1; }
}
