package dev.nexora.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Version-fragile Minecraft calls live here so a Yarn rename is a one-file fix. All UNVERIFIED on 1.21.11. */
public final class Compat {
    private Compat() {}

    public static int selectedSlot(PlayerInventory inv) { return inv.getSelectedSlot(); }
    public static void selectSlot(PlayerInventory inv, int slot) { inv.setSelectedSlot(slot); }

    public static Vec3d pos(Entity e) { return new Vec3d(e.getX(), e.getY(), e.getZ()); }

    public static float partialTick(MinecraftClient mc) { return mc.getRenderTickCounter().getTickProgress(false); }

    /** Offset from the entity's tick position to its interpolated render position. */
    public static double[] renderOffset(Entity e, float pt) {
        return new double[] {
            MathHelper.lerp(pt, e.lastRenderX, e.getX()) - e.getX(),
            MathHelper.lerp(pt, e.lastRenderY, e.getY()) - e.getY(),
            MathHelper.lerp(pt, e.lastRenderZ, e.getZ()) - e.getZ() };
    }

    public static boolean firstPerson(MinecraftClient mc) { return mc.options.getPerspective().isFirstPerson(); }

    /** First-person camera projection; ignores dynamic FOV effects (sprint/speed) and third person. */
    public static Projection projection(MinecraftClient mc, float pt) {
        var p = mc.player;
        double x = MathHelper.lerp(pt, p.lastRenderX, p.getX());
        double y = MathHelper.lerp(pt, p.lastRenderY, p.getY()) + p.getEyeHeight(p.getPose());
        double z = MathHelper.lerp(pt, p.lastRenderZ, p.getZ());
        return new Projection(x, y, z, p.getYaw(pt), p.getPitch(pt), mc.options.getFov().getValue(),
                              mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
    }
}
