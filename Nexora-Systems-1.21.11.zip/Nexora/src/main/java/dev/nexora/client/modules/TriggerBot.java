package dev.nexora.client.modules;

import dev.nexora.client.MaceMath;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/** Attacks when the crosshair is on a player and the weapon is charged. */
public final class TriggerBot extends Module {
    private final Setting minCharge = add(new Setting("Min charge", 0.95, 0.5, 1.0, 0.05));
    private final Setting smashOnly = add(Setting.toggle("Smash only", false));
    private final Setting minFall   = add(new Setting("Smash min fall", 1.5, 1.5, 12.0, 0.5));

    @Override public String name() { return "TriggerBot"; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || !mc.isWindowFocused()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!(e instanceof PlayerEntity t) || t == p || !t.isAlive() || t.isSpectator()) return;

        float charge = p.getAttackCooldownProgress(0.5f);
        if (charge < minCharge.get()) return;
        if (smashOnly.on() && p.getMainHandStack().isOf(Items.MACE) && !p.isOnGround()
            && !MaceMath.isSmashReady(p.fallDistance, minFall.get(), charge)) return;

        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }
}
