package dev.nexora.client.modules;

import dev.nexora.client.CombatMath;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/** Attacks the player under the crosshair only while a critical hit is possible (falling, not sprinting). */
public final class AutoCrit extends Module {
    private final Setting minCharge = add(new Setting("Min charge", 0.95, 0.5, 1.0, 0.05));

    @Override public String name() { return "AutoCrit"; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (mc.currentScreen != null || !mc.isWindowFocused()) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity e = hit.getEntity();
        if (!(e instanceof PlayerEntity t) || t == p || !t.isAlive() || t.isSpectator()) return;
        if (p.getAttackCooldownProgress(0.5f) < minCharge.get()) return;
        if (!CombatMath.canCrit(p.fallDistance, p.isOnGround(), p.isClimbing(), p.isTouchingWater(),
                p.hasStatusEffect(StatusEffects.BLINDNESS), p.hasVehicle(), p.isSprinting())) return;

        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }
}
