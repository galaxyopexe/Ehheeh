package dev.nexora.client.ui;

import dev.nexora.client.Module;
import dev.nexora.client.Module.Category;
import dev.nexora.client.ModuleManager;
import dev.nexora.client.Palette;
import dev.nexora.client.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Nexora menu. Mouse/touch is polled through GLFW (phones emulate it), so input-event signature changes can't break it.
 * Tap a row to toggle, drag a slider, drag empty space to scroll.
 */
public final class MenuScreen extends Screen {
    private static final int HEADER = 42, TABS = 28, FOOT = 18, ROW = 30, SROW = 34, PAD = 12, TAP_SLOP = 6;
    private static Category tab = Category.COMBAT;

    private final ModuleManager modules;
    private final Path cfg;
    private boolean wasDown, panning, pressInside;
    private int pressX, pressY;
    private double scroll, scrollStart;
    private Setting dragging;

    public MenuScreen(ModuleManager modules, Path cfg) {
        super(Text.literal("Nexora Systems"));
        this.modules = modules;
        this.cfg = cfg;
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { modules.save(cfg); }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scroll -= vertical * 20;
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long handle = client.getWindow().getHandle();
        boolean down = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean pressEdge = down && !wasDown, release = !down && wasDown;
        wasDown = down;

        int W = Math.min(340, width - 12);
        int contentH = 0;
        for (Module m : modules.all()) {
            if (m.category() != tab) continue;
            contentH += ROW;
            if (m.enabled()) contentH += SROW * m.settings().size();
        }
        int ph = Math.min(height - 12, HEADER + TABS + contentH + FOOT + 6);
        int px = (width - W) / 2, py = (height - ph) / 2;
        int vy1 = py + HEADER + TABS, vy2 = py + ph - FOOT;
        boolean inPanel = mx >= px && mx < px + W && my >= py && my < py + ph;

        if (pressEdge) { pressX = mx; pressY = my; pressInside = inPanel; panning = false; scrollStart = scroll; }
        if (down && dragging == null && pressInside && Math.abs(my - pressY) > TAP_SLOP) panning = true;
        if (panning && down) scroll = scrollStart - (my - pressY);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - (vy2 - vy1))));
        boolean tap = release && !panning && dragging == null && pressInside;
        int tx = pressX, ty = pressY;
        if (!down) dragging = null;

        // --- panel and header ---
        ctx.fill(0, 0, width, height, Palette.SCRIM);
        ctx.fill(px, py, px + W, py + ph, Palette.PANEL);
        ctx.fill(px, py, px + W, py + HEADER, Palette.HEADER_BG);
        ctx.fill(px, py + HEADER - 2, px + W, py + HEADER, Palette.VIOLET);
        border(ctx, px, py, W, ph);

        MutableText title = Text.literal("NEX").formatted(Formatting.BOLD)
            .append(Text.literal("O").setStyle(Style.EMPTY.withBold(true).withColor(0x8B5CF6)))
            .append(Text.literal("RA").formatted(Formatting.BOLD));
        ctx.drawText(textRenderer, title, px + PAD, py + 9, Palette.ICE, false);
        ctx.drawText(textRenderer, "S Y S T E M S", px + PAD, py + 22, Palette.PURPLE, false);
        String ver = "1.21.11";
        ctx.drawText(textRenderer, ver, px + W - PAD - textRenderer.getWidth(ver), py + 15, Palette.MUTED, false);

        // --- tabs ---
        Category[] cats = Category.values();
        int tabW = (W - 2 * PAD) / cats.length, ty0 = py + HEADER + 4;
        for (int i = 0; i < cats.length; i++) {
            int x = px + PAD + i * tabW;
            boolean sel = cats[i] == tab;
            if (tap && hit(tx, ty, x, ty0, tabW, TABS - 6)) { tab = cats[i]; scroll = 0; }
            int cw = textRenderer.getWidth(cats[i].label);
            ctx.drawText(textRenderer, cats[i].label, x + (tabW - cw) / 2, ty0 + 7, sel ? Palette.ICE : Palette.MUTED, false);
            if (sel) ctx.fill(x + 6, ty0 + TABS - 8, x + tabW - 6, ty0 + TABS - 6, Palette.VIOLET);
        }

        // --- rows ---
        ctx.enableScissor(px + 1, vy1, px + W - 1, vy2);
        int y = vy1 - (int) scroll;
        for (Module m : modules.all()) {
            if (m.category() != tab) continue;
            boolean hover = my >= Math.max(y, vy1) && my < Math.min(y + ROW, vy2) && mx >= px && mx < px + W;
            if (hover) ctx.fill(px + 1, y, px + W - 1, y + ROW, Palette.ROW_HOVER);
            if (tap && hit(tx, ty, px, y, W, ROW) && ty >= vy1 && ty < vy2) m.toggle();
            boolean on = m.enabled();
            ctx.drawText(textRenderer, m.name(), px + PAD, y + 11, on ? Palette.ICE : Palette.MUTED, false);
            if (!m.info().isEmpty() && on)
                ctx.drawText(textRenderer, m.info(), px + PAD + textRenderer.getWidth(m.name()) + 6, y + 11, Palette.PURPLE, false);
            pill(ctx, px + W - PAD - 30, y + 8, on);
            y += ROW;
            if (!on) continue;
            for (Setting s : m.settings()) {
                setting(ctx, s, px, W, y, mx, my, pressEdge, tap, tx, ty, vy1, vy2);
                y += SROW;
            }
        }
        ctx.disableScissor();

        String hint = "Right Shift  /  /nexora";
        ctx.drawText(textRenderer, hint, px + (W - textRenderer.getWidth(hint)) / 2, py + ph - FOOT + 5, Palette.MUTED, false);
    }

    private void setting(DrawContext ctx, Setting s, int px, int W, int y, int mx, int my,
                         boolean pressEdge, boolean tap, int tx, int ty, int vy1, int vy2) {
        int lx = px + PAD + 8;
        ctx.drawText(textRenderer, s.name(), lx, y + 5, Palette.MUTED, false);
        boolean visibleTap = ty >= vy1 && ty < vy2;

        if (s.isToggle()) {
            pill(ctx, px + W - PAD - 30, y + 4, s.on());
            if (tap && visibleTap && hit(tx, ty, px, y, W, SROW)) s.set(s.on() ? 0 : 1);
            return;
        }

        String val = String.format(Locale.ROOT, "%.2f", s.get());
        ctx.drawText(textRenderer, val, px + W - PAD - textRenderer.getWidth(val), y + 5, Palette.PURPLE, false);

        int sx = lx, sw = W - 2 * PAD - 16, sy = y + 21;
        if (pressEdge && my >= vy1 && my < vy2 && hit(mx, my, sx - 8, sy - 9, sw + 16, 22)) dragging = s;
        if (dragging == s) s.setFraction((mx - sx) / (double) sw);

        int fillW = (int) Math.round(sw * s.fraction());
        ctx.fill(sx, sy, sx + sw, sy + 5, Palette.TRACK);
        ctx.fill(sx, sy, sx + fillW, sy + 5, Palette.PURPLE);
        ctx.fill(sx + fillW - 3, sy - 4, sx + fillW + 3, sy + 9, Palette.ICE);
    }

    private void pill(DrawContext ctx, int x, int y, boolean on) {
        ctx.fill(x, y, x + 30, y + 14, on ? Palette.VIOLET : Palette.TRACK);
        int kx = on ? x + 18 : x + 2;
        ctx.fill(kx, y + 2, kx + 10, y + 12, on ? Palette.ICE : Palette.MUTED);
    }

    private static void border(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + 1, Palette.VIOLET);
        ctx.fill(x, y + h - 1, x + w, y + h, Palette.VIOLET);
        ctx.fill(x, y, x + 1, y + h, Palette.VIOLET);
        ctx.fill(x + w - 1, y, x + w, y + h, Palette.VIOLET);
    }

    private static boolean hit(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }
}
