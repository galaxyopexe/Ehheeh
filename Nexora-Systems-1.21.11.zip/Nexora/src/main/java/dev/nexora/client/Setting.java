package dev.nexora.client;

public final class Setting {
    private final String name;
    private final double min, max, step;
    private double value;

    public Setting(String name, double def, double min, double max, double step) {
        this.name = name; this.min = min; this.max = max; this.step = step;
        this.value = clampSnap(def, min, max, step);
    }

    public static Setting toggle(String name, boolean def) { return new Setting(name, def ? 1 : 0, 0, 1, 1); }

    public String name() { return name; }
    public double get() { return value; }
    public boolean on() { return value >= 0.5; }
    public boolean isToggle() { return min == 0 && max == 1 && step == 1; }
    public void set(double v) { value = clampSnap(v, min, max, step); }
    public double fraction() { return max > min ? (value - min) / (max - min) : 0; }
    public void setFraction(double f) {
        if (!Double.isFinite(f)) return;
        set(min + Math.max(0, Math.min(1, f)) * (max - min));
    }

    public static double clampSnap(double v, double min, double max, double step) {
        if (!Double.isFinite(v)) return min;
        double r = step > 0 ? min + Math.round((v - min) / step) * step : v;
        return Math.max(min, Math.min(max, r));
    }
}
