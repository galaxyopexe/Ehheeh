package dev.nexora.client;

public final class AimMath {
    private AimMath() {}

    public static float wrapDegrees(float d) {
        d %= 360f;
        if (d >= 180f) d -= 360f;
        if (d < -180f) d += 360f;
        return d;
    }

    public static double angularDistance(float dYaw, float dPitch) { return Math.hypot(dYaw, dPitch); }
    public static float limit(float v, float m) { return Math.max(-m, Math.min(m, v)); }

    /** Per-tick rotation delta {yaw, pitch} toward a target: proportional smoothing, capped per tick. */
    public static float[] step(float yaw, float pitch, float tYaw, float tPitch, float smoothing, float maxStep) {
        float dy = wrapDegrees(tYaw - yaw);
        float dp = tPitch - pitch;
        return new float[] { limit(dy * smoothing, maxStep), limit(dp * smoothing, maxStep) };
    }
}
