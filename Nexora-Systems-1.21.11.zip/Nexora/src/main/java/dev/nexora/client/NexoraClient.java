package dev.nexora.client;

import dev.nexora.client.modules.*;
import dev.nexora.client.ui.MenuScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Path;

public final class NexoraClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();
    private static boolean menuKeyWasDown;
    private static volatile boolean openRequested;

    @Override
    public void onInitializeClient() {
        MODULES.register(new MaceAura());
        MODULES.register(new AutoMaceSwap());
        MODULES.register(new WindBurst());
        MODULES.register(new AimAssist());
        MODULES.register(new TriggerBot());
        MODULES.register(new SwordAura());
        MODULES.register(new AutoCrit());
        MODULES.register(new WTap());
        MODULES.register(new AutoSword());
        MODULES.register(new ShieldBreaker());
        MODULES.register(new JumpReset());
        MODULES.register(new Hitbox());
        MODULES.register(new AutoTotem());
        MODULES.register(new Esp());
        MODULES.register(new Sprint());
        Hud hud = new Hud();
        MODULES.register(hud); // last, so it draws over the other overlays

        Path cfg = FabricLoader.getInstance().getConfigDir().resolve("nexora.properties");
        if (!MODULES.load(cfg)) hud.toggle(); // first run: HUD on

        // Phone-friendly way to open the menu: type /nexora in chat.
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("nexora").executes(c -> { openRequested = true; return 1; })));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            MODULES.tick(client);
            pollMenu(client, cfg);
        });
    }

    /** Right Shift, polled directly so one edge detector owns both open and close. */
    private static void pollMenu(MinecraftClient mc, Path cfg) {
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        boolean rising = down && !menuKeyWasDown;
        menuKeyWasDown = down;

        if (openRequested && mc.currentScreen == null) {
            openRequested = false;
            mc.setScreen(new MenuScreen(MODULES, cfg));
            return;
        }
        if (!rising) return;
        if (mc.currentScreen instanceof MenuScreen) mc.setScreen(null);
        else if (mc.currentScreen == null) mc.setScreen(new MenuScreen(MODULES, cfg));
    }
}
