package dev.nexora.client;

public final class MaceMath {
    private MaceMath() {}

    public static final double MIN_SMASH_FALL = 1.5; // assumption: 1.21.x rule, verify in game

    /** Bonus damage from fall distance: 4/block for first 3, 2/block for next 5, 1/block after. */
    public static double smashBonus(double fall) {
        if (!Double.isFinite(fall) || fall <= MIN_SMASH_FALL) return 0.0;
        double t1 = Math.min(fall, 3.0) * 4.0;
        double t2 = Math.max(0.0, Math.min(fall, 8.0) - 3.0) * 2.0;
        double t3 = Math.max(0.0, fall - 8.0);
        return t1 + t2 + t3;
    }

    public static boolean isSmashReady(double fall, double minFall, float cooldown) {
        return Double.isFinite(fall) && fall > Math.max(minFall, MIN_SMASH_FALL) && cooldown >= 0.95f;
    }

    /** Degrees. Minecraft yaw 0 = +Z, yaw -90 = +X, pitch positive = looking down. */
    public static float[] lookAngles(double dx, double dy, double dz) {
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, horiz));
        return new float[] { yaw, pitch };
    }
}
