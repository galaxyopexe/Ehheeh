package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.item.Items;

/** Swaps to the mace while airborne and falling, back to the previous slot on landing. */
public final class AutoMaceSwap extends Module {
    private final Setting swapBack = add(Setting.toggle("Swap back", true));
    private int previousSlot = -1;

    @Override public String name() { return "AutoMaceSwap"; }
    @Override public Category category() { return Category.MACE; }

    @Override
    protected void onTick() {
        var p = mc.player;
        var inv = p.getInventory();
        boolean falling = !p.isOnGround() && p.getVelocity().y < -0.1 && p.fallDistance > 1.0;

        if (falling && previousSlot < 0) {
            for (int i = 0; i < 9; i++) {
                if (inv.getStack(i).isOf(Items.MACE)) {
                    previousSlot = Compat.selectedSlot(inv);
                    if (previousSlot == i) { previousSlot = -1; return; }
                    Compat.selectSlot(inv, i);
                    return;
                }
            }
        } else if (p.isOnGround() && previousSlot >= 0) {
            if (swapBack.on()) Compat.selectSlot(inv, previousSlot);
            previousSlot = -1;
        }
    }

    @Override protected void onDisable() { previousSlot = -1; }
}
