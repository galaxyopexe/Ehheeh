package dev.nexora.client;

import net.minecraft.client.gui.DrawContext;

/** 2D line and box drawing on top of DrawContext.fill (no GL state needed). */
public final class Draw {
    private Draw() {}

    private static final int[][] EDGES = {
        {0,1},{1,3},{3,2},{2,0}, {4,5},{5,7},{7,6},{6,4}, {0,4},{1,5},{2,6},{3,7} };

    public static void line(DrawContext ctx, float x1, float y1, float x2, float y2, int color, int t) {
        if (!(Float.isFinite(x1) && Float.isFinite(y1) && Float.isFinite(x2) && Float.isFinite(y2))) return;
        if (Math.max(Math.max(Math.abs(x1), Math.abs(y1)), Math.max(Math.abs(x2), Math.abs(y2))) > 20000f) return;
        float dx = x2 - x1, dy = y2 - y1;
        int n = Math.min(500, Math.max(1, (int) (Math.max(Math.abs(dx), Math.abs(dy)) / t)));
        for (int i = 0; i <= n; i++) {
            int x = Math.round(x1 + dx * i / n), y = Math.round(y1 + dy * i / n);
            ctx.fill(x, y, x + t, y + t, color);
        }
    }

    public static void box(DrawContext ctx, Projection pr, double x0, double y0, double z0,
                           double x1, double y1, double z1, int color, int t) {
        double[][] c = new double[8][];
        for (int i = 0; i < 8; i++)
            c[i] = new double[] { (i & 1) == 0 ? x0 : x1, (i & 2) == 0 ? y0 : y1, (i & 4) == 0 ? z0 : z1 };
        for (int[] e : EDGES) {
            float[] s = pr.segment(c[e[0]][0], c[e[0]][1], c[e[0]][2], c[e[1]][0], c[e[1]][1], c[e[1]][2]);
            if (s != null) line(ctx, s[0], s[1], s[2], s[3], color, t);
        }
    }
}
