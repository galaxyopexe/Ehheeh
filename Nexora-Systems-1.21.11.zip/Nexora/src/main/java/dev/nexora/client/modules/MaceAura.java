package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.MaceMath;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public final class MaceAura extends Module {
    private final Setting range     = add(new Setting("Range", 3.0, 2.0, 6.0, 0.1));
    private final Setting minFall   = add(new Setting("Min fall", 1.5, 1.5, 12.0, 0.5));
    private final Setting lowestHp  = add(Setting.toggle("Lowest HP first", false));

    @Override public String name() { return "MaceAura"; }
    @Override public Category category() { return Category.MACE; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (!p.getMainHandStack().isOf(Items.MACE)) return;
        if (p.isOnGround() || p.isTouchingWater() || p.isClimbing()) return;
        if (!MaceMath.isSmashReady(p.fallDistance, minFall.get(), p.getAttackCooldownProgress(0.5f))) return;
        if (mc.currentScreen != null || !mc.isWindowFocused()) return;

        Vec3d eye = p.getEyePos();
        PlayerEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator()) continue;
            double d = eye.distanceTo(Compat.pos(other).add(0, other.getHeight() * 0.5, 0));
            if (!Double.isFinite(d) || d > range.get()) continue;
            double score = lowestHp.on() ? other.getHealth() : d;
            if (score < bestScore) { bestScore = score; best = other; }
        }
        if (best == null) return;

        Vec3d tgt = Compat.pos(best).add(0, best.getHeight() * 0.5, 0);
        float[] ang = MaceMath.lookAngles(tgt.x - eye.x, tgt.y - eye.y, tgt.z - eye.z);
        p.setYaw(ang[0]);
        p.setPitch(ang[1]);

        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
