package dev.nexora.client;

/** Official Nexora palette (ARGB). Derived shades are mixes of the four official colors. */
public final class Palette {
    private Palette() {}

    public static final int VIOLET   = 0xFF8B5CF6;
    public static final int PURPLE   = 0xFFA78BFA;
    public static final int ICE      = 0xFFF8FAFC;
    public static final int MIDNIGHT = 0xFF09090F;

    public static final int PANEL     = 0xF209090F;
    public static final int SCRIM     = 0x9909090F;
    public static final int HEADER_BG = mix(MIDNIGHT, VIOLET, 0.22);
    public static final int ROW_HOVER = mix(MIDNIGHT, VIOLET, 0.14);
    public static final int TRACK     = mix(MIDNIGHT, ICE, 0.16);
    public static final int MUTED     = mix(MIDNIGHT, ICE, 0.62);

    public static int mix(int a, int b, double t) {
        int out = 0xFF000000;
        for (int s = 16; s >= 0; s -= 8) {
            int ca = (a >> s) & 0xFF, cb = (b >> s) & 0xFF;
            out |= ((int) Math.round(ca + (cb - ca) * t) & 0xFF) << s;
        }
        return out;
    }

    /** Fully saturated rainbow color for h in [0,1). */
    public static int hue(float h) {
        float x = ((h % 1f) + 1f) % 1f * 6f;
        int r = ch(Math.abs(x - 3f) - 1f), g = ch(2f - Math.abs(x - 2f)), b = ch(2f - Math.abs(x - 4f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static int ch(float v) { return Math.round(Math.max(0f, Math.min(1f, v)) * 255f); }
}
