package dev.nexora.client.modules;

import dev.nexora.client.Module;

/** Jumps right as you take a hit while grounded, which shortens the knockback you take. */
public final class JumpReset extends Module {
    private boolean used;

    @Override public String name() { return "JumpReset"; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (p.hurtTime == 0) { used = false; return; }
        if (used || p.hurtTime < 8) return;
        if (p.isOnGround() && !p.isTouchingWater() && !p.isClimbing() && mc.currentScreen == null) {
            p.jump();
            used = true;
        }
    }
}
