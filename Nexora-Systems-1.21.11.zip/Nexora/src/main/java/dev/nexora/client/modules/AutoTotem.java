package dev.nexora.client.modules;

import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class AutoTotem extends Module {
    private final Setting health = add(new Setting("Health", 20, 4, 20, 1));
    private final Setting delay  = add(new Setting("Delay ticks", 4, 0, 10, 1));
    private int cooldownTicks;

    @Override public String name() { return "AutoTotem"; }

    @Override
    protected void onTick() {
        if (cooldownTicks > 0) { cooldownTicks--; return; }
        var p = mc.player;
        if (p.getHealth() > health.get()) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        var inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            if (!inv.getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int screenSlot = i < 9 ? 36 + i : i; // hotbar 0-8 -> 36-44, main 9-35 -> 9-35
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, screenSlot, 40,
                                            SlotActionType.SWAP, p); // button 40 = offhand
            cooldownTicks = (int) delay.get();
            return;
        }
    }
}
