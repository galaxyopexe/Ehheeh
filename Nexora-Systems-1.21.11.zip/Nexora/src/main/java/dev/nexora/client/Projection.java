package dev.nexora.client;

/**
 * World-to-screen for a perspective camera. Coordinates: Minecraft world (Y up), yaw/pitch in degrees
 * (yaw 0 = +Z, pitch positive = down), fovY is the vertical FOV in degrees, screen origin top-left.
 */
public final class Projection {
    public static final double NEAR = 0.05;
    private final double cx, cy, cz, rx, rz, ux, uy, uz, fx, fy, fz, tanHalf, aspect;
    private final int w, h;

    public Projection(double camX, double camY, double camZ, float yawDeg, float pitchDeg,
                      double fovYDeg, int w, int h) {
        cx = camX; cy = camY; cz = camZ; this.w = w; this.h = h;
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        double cp = Math.cos(pitch), sp = Math.sin(pitch), cw = Math.cos(yaw), sw = Math.sin(yaw);
        fx = -sw * cp; fy = -sp; fz = cw * cp;
        rx = -cw; rz = -sw;
        ux = -rz * fy; uy = rz * fx - rx * fz; uz = rx * fy;
        tanHalf = Math.tan(Math.toRadians(fovYDeg) / 2.0);
        aspect = h > 0 ? (double) w / h : 1.0;
    }

    /** {right, up, forward} distances of a world point from the camera. */
    public double[] toCamera(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        return new double[] { dx * rx + dz * rz, dx * ux + dy * uy + dz * uz, dx * fx + dy * fy + dz * fz };
    }

    private float[] screen(double x, double y, double z) {
        double nx = x / (z * tanHalf * aspect), ny = y / (z * tanHalf);
        return new float[] { (float) ((nx + 1) * 0.5 * w), (float) ((1 - ny) * 0.5 * h) };
    }

    /** {sx, sy}, or null when the point is behind the near plane. */
    public float[] point(double x, double y, double z) {
        double[] c = toCamera(x, y, z);
        return c[2] < NEAR ? null : screen(c[0], c[1], c[2]);
    }

    /** {x1, y1, x2, y2} with the near plane clipped, or null when fully behind the camera. */
    public float[] segment(double ax, double ay, double az, double bx, double by, double bz) {
        double[] a = toCamera(ax, ay, az), b = toCamera(bx, by, bz);
        if (a[2] < NEAR && b[2] < NEAR) return null;
        if (a[2] < NEAR) a = clip(a, b); else if (b[2] < NEAR) b = clip(b, a);
        float[] pa = screen(a[0], a[1], a[2]), pb = screen(b[0], b[1], b[2]);
        return new float[] { pa[0], pa[1], pb[0], pb[1] };
    }

    private static double[] clip(double[] behind, double[] front) {
        double t = (NEAR - behind[2]) / (front[2] - behind[2]);
        return new double[] { behind[0] + (front[0] - behind[0]) * t, behind[1] + (front[1] - behind[1]) * t, NEAR };
    }
}
