package dev.nexora.client.modules;

import dev.nexora.client.AimMath;
import dev.nexora.client.Compat;
import dev.nexora.client.MaceMath;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Mace aim assist: while holding the mace, eases the crosshair toward the nearest player in the cone. */
public final class AimAssist extends Module {
    // Smoothing and step values are untuned defaults (uncalibrated).
    private final Setting range     = add(new Setting("Range", 6.0, 3.0, 8.0, 0.5));
    private final Setting fov       = add(new Setting("FOV radius", 70, 10, 180, 5));
    private final Setting smoothing = add(new Setting("Smoothing", 0.20, 0.05, 1.0, 0.05));
    private final Setting maxStep   = add(new Setting("Max step", 8, 1, 30, 1));
    private final Setting needClick = add(Setting.toggle("Need attack key", true));

    @Override public String name() { return "AimAssist"; }
    @Override public Category category() { return Category.MACE; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (!p.getMainHandStack().isOf(Items.MACE)) return;
        if (mc.currentScreen != null || !mc.isWindowFocused()) return;
        if (needClick.on() && !mc.options.attackKey.isPressed()) return;

        Vec3d eye = p.getEyePos();
        float yaw = p.getYaw(), pitch = p.getPitch();
        float[] bestAngles = null;
        double bestAng = fov.get();

        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator()) continue;
            Vec3d aim = Compat.pos(other).add(0, other.getHeight() * 0.7, 0);
            double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (!Double.isFinite(dist) || dist > range.get()) continue;
            float[] a = MaceMath.lookAngles(dx, dy, dz);
            double ang = AimMath.angularDistance(AimMath.wrapDegrees(a[0] - yaw), a[1] - pitch);
            if (ang < bestAng) { bestAng = ang; bestAngles = a; }
        }
        if (bestAngles == null) return;

        float[] d = AimMath.step(yaw, pitch, bestAngles[0], bestAngles[1],
                                 (float) smoothing.get(), (float) maxStep.get());
        p.setYaw(yaw + d[0]);
        p.setPitch(MathHelper.clamp(pitch + d[1], -90f, 90f));
    }
}
