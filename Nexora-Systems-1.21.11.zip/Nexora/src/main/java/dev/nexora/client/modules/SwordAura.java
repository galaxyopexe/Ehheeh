package dev.nexora.client.modules;

import dev.nexora.client.AimMath;
import dev.nexora.client.Compat;
import dev.nexora.client.CombatMath;
import dev.nexora.client.MaceMath;
import dev.nexora.client.Module;
import dev.nexora.client.Setting;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Sword aura: eases toward the best player in the cone and attacks once the sword is charged. Values are untuned. */
public final class SwordAura extends Module {
    private final Setting range     = add(new Setting("Range", 3.0, 2.0, 6.0, 0.1));
    private final Setting fov       = add(new Setting("FOV", 120, 30, 360, 10));
    private final Setting minCharge = add(new Setting("Min charge", 0.95, 0.5, 1.0, 0.05));
    private final Setting rotate    = add(Setting.toggle("Rotate", true));
    private final Setting smoothing = add(new Setting("Smoothing", 0.35, 0.05, 1.0, 0.05));
    private final Setting maxStep   = add(new Setting("Max step", 20, 1, 60, 1));
    private final Setting critsOnly = add(Setting.toggle("Crits only", false));
    private final Setting lowestHp  = add(Setting.toggle("Lowest HP first", false));

    @Override public String name() { return "SwordAura"; }

    @Override
    protected void onTick() {
        var p = mc.player;
        if (!p.getMainHandStack().isIn(ItemTags.SWORDS)) return;
        if (mc.currentScreen != null || !mc.isWindowFocused()) return;

        Vec3d eye = p.getEyePos();
        float yaw = p.getYaw(), pitch = p.getPitch();
        PlayerEntity best = null;
        float[] bestAngles = null;
        double bestScore = Double.MAX_VALUE;

        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            Vec3d aim = Compat.pos(o).add(0, o.getHeight() * 0.6, 0);
            double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (!Double.isFinite(dist) || dist > range.get()) continue;
            float[] a = MaceMath.lookAngles(dx, dy, dz);
            double ang = AimMath.angularDistance(AimMath.wrapDegrees(a[0] - yaw), a[1] - pitch);
            if (ang > fov.get() / 2.0) continue;
            double score = lowestHp.on() ? o.getHealth() : dist;
            if (score < bestScore) { bestScore = score; best = o; bestAngles = a; }
        }
        if (best == null) return;

        if (rotate.on()) {
            float[] d = AimMath.step(yaw, pitch, bestAngles[0], bestAngles[1],
                                     (float) smoothing.get(), (float) maxStep.get());
            p.setYaw(yaw + d[0]);
            p.setPitch(MathHelper.clamp(pitch + d[1], -90f, 90f));
            double left = AimMath.angularDistance(AimMath.wrapDegrees(bestAngles[0] - p.getYaw()), bestAngles[1] - p.getPitch());
            if (left > 35.0) return; // wait until the aim has caught up
        }

        if (p.getAttackCooldownProgress(0.5f) < minCharge.get()) return;
        if (critsOnly.on() && !CombatMath.canCrit(p.fallDistance, p.isOnGround(), p.isClimbing(),
                p.isTouchingWater(), p.hasStatusEffect(StatusEffects.BLINDNESS), p.hasVehicle(), p.isSprinting())) return;

        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
    }
}
