package dev.nexora.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module m) { modules.add(m); }
    public List<Module> all() { return Collections.unmodifiableList(modules); }

    public void tick(MinecraftClient client) { for (Module m : modules) m.tick(); }

    public void render(DrawContext ctx, float pt) {
        var mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        for (Module m : modules) m.renderTick(ctx, pt);
    }

    /** @return false when no config file existed (first run). */
    public boolean load(Path file) {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file)) { p.load(in); } catch (IOException e) { return false; }
        for (Module m : modules) {
            for (Setting s : m.settings()) {
                String v = p.getProperty(m.name() + "." + s.name());
                if (v == null) continue;
                try { s.set(Double.parseDouble(v)); } catch (NumberFormatException ignored) {}
            }
            String en = p.getProperty(m.name() + ".enabled");
            if (en != null && Boolean.parseBoolean(en) != m.enabled()) m.toggle();
        }
        return true;
    }

    public void save(Path file) {
        Properties p = new Properties();
        for (Module m : modules) {
            p.setProperty(m.name() + ".enabled", Boolean.toString(m.enabled()));
            for (Setting s : m.settings()) p.setProperty(m.name() + "." + s.name(), Double.toString(s.get()));
        }
        try {
            Files.createDirectories(file.getParent());
            try (OutputStream out = Files.newOutputStream(file)) { p.store(out, "Nexora Systems"); }
        } catch (IOException ignored) {}
    }
}
