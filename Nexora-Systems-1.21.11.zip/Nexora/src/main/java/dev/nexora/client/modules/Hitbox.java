package dev.nexora.client.modules;

import dev.nexora.client.Compat;
import dev.nexora.client.Draw;
import dev.nexora.client.Module;
import dev.nexora.client.Palette;
import dev.nexora.client.Projection;
import dev.nexora.client.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import java.util.Locale;

/**
 * Client-side targeting margin for other players, plus an outline that shows the expansion.
 * Outline: real hitbox in Ice White, expanded hitbox in rainbow (RGB on) or a Violet/Purple pulse (RGB off).
 * The server still uses the real boxes.
 */
public final class Hitbox extends Module {
    private static volatile Hitbox instance;
    private final Setting expand    = add(new Setting("Expand", 0.3, 0.0, 1.0, 0.05));
    private final Setting outline   = add(Setting.toggle("Outline", true));
    private final Setting rgb       = add(Setting.toggle("RGB", true));
    private final Setting showReal  = add(Setting.toggle("Show real box", true));
    private final Setting range     = add(new Setting("Outline range", 24, 6, 64, 2));

    public Hitbox() { instance = this; }

    @Override public String name() { return "Hitbox"; }
    @Override public String info() { return String.format(Locale.ROOT, "+%.2f", expand.get()); }

    public static float marginFor(net.minecraft.entity.Entity e) {
        Hitbox h = instance;
        if (h == null || !h.enabled()) return 0f;
        var self = h.mc.player;
        if (self == null || e == self || !(e instanceof PlayerEntity)) return 0f;
        return (float) h.expand.get();
    }

    @Override
    protected void onRender(DrawContext ctx, float pt) {
        if (!outline.on() || !Compat.firstPerson(mc)) return;
        Projection pr = Compat.projection(mc, pt);
        double ex = expand.get();
        double t = (System.nanoTime() / 1.0e9);
        int color = rgb.on() ? Palette.hue((float) (t * 0.25 % 1.0))
                             : Palette.mix(Palette.VIOLET, Palette.PURPLE, (Math.sin(t * 3.0) + 1) / 2);

        int drawn = 0;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == mc.player || !o.isAlive() || o.isSpectator() || drawn >= 12) continue;
            if (mc.player.distanceTo(o) > range.get()) continue;
            Box b = o.getBoundingBox();
            double[] off = Compat.renderOffset(o, pt);
            double x0 = b.minX + off[0], y0 = b.minY + off[1], z0 = b.minZ + off[2];
            double x1 = b.maxX + off[0], y1 = b.maxY + off[1], z1 = b.maxZ + off[2];
            if (showReal.on()) Draw.box(ctx, pr, x0, y0, z0, x1, y1, z1, Palette.ICE, 1);
            Draw.box(ctx, pr, x0 - ex, y0 - ex, z0 - ex, x1 + ex, y1 + ex, z1 + ex, color, 2);

            float[] top = pr.point((x0 + x1) / 2, y1 + ex, (z0 + z1) / 2);
            if (top != null) {
                String label = String.format(Locale.ROOT, "+%.2f  width %.2f", ex, o.getWidth() + 2 * ex);
                ctx.drawText(mc.textRenderer, label, Math.round(top[0]) - mc.textRenderer.getWidth(label) / 2,
                             Math.round(top[1]) - 12, Palette.ICE, true);
            }
            drawn++;
        }
    }
}
