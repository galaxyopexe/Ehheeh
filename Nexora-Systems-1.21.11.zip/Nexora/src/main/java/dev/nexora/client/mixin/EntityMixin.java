package dev.nexora.client.mixin;

import dev.nexora.client.modules.Hitbox;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    // Yarn name; if it fails to apply, look up the targeting-margin method on Entity for your build.
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void nexora$expandHitbox(CallbackInfoReturnable<Float> cir) {
        float extra = Hitbox.marginFor((Entity) (Object) this);
        if (extra > 0f) cir.setReturnValue(cir.getReturnValue() + extra);
    }
}
