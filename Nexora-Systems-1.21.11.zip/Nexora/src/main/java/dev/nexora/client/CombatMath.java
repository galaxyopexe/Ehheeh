package dev.nexora.client;

public final class CombatMath {
    private CombatMath() {}

    /** Vanilla 1.9+ critical-hit conditions (sprinting hits cannot crit). Verify against your version. */
    public static boolean canCrit(double fallDistance, boolean onGround, boolean climbing, boolean inWater,
                                  boolean blind, boolean riding, boolean sprinting) {
        return Double.isFinite(fallDistance) && fallDistance > 0.0
            && !onGround && !climbing && !inWater && !blind && !riding && !sprinting;
    }
}
